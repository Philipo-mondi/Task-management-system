import LoginForm from '../components/LoginForm'
import './home.css'

function Home() {
  return (
    <div className='home'>
      <div className="home-formWrapper">
        <LoginForm />
      </div>
    </div>

  )
}

export default Home


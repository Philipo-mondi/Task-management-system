import Sidenav from "../components/Sidenav"
import Mainnav from "../components/Mainnav"
export default function Tasks() {
 
  return (
    <div style={{ height: '85vh', display: "flex"}}>
      <Sidenav />
      <Mainnav />
        
      
    </div>
  )
}

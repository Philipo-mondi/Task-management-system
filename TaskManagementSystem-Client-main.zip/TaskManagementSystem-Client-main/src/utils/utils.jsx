// export const apiDomain = 'http://localhost:8082';
export const apiDomain = 'https://taskmanagementappapi.azurewebsites.net';